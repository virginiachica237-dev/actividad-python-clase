class Producto:
    def __init__(self, nombre, precio, disponible=True):
        self.nombre = nombre
        self._precio = precio
        self.disponible = disponible

    def obtener_precio(self):
        return self._precio

    def cambiar_precio(self, nuevo_precio):
        if nuevo_precio > 0:
            self._precio = nuevo_precio
        else:
            print("Error: el precio debe ser positivo.")
