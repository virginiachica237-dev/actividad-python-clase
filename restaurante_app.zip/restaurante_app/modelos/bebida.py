from modelos.producto import Producto

class Bebida(Producto):
    def __init__(self, nombre, precio, volumen_ml, alcoholica, disponible=True):
        super().__init__(nombre, precio, disponible)
        self.volumen_ml = volumen_ml
        self.alcoholica = alcoholica
