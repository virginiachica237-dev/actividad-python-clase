from modelos.producto import Producto

class Platillo(Producto):
    def __init__(self, nombre, precio, calorias, tiempo_preparacion, disponible=True):
        super().__init__(nombre, precio, disponible)
        self.calorias = calorias
        self.tiempo_preparacion = tiempo_preparacion
