class Restaurante:
    def __init__(self):
        self.productos = []

    def agregar_producto(self, producto):
        self.productos.append(producto)

    def mostrar_menu(self):
        print("\n=== MENÚ DEL RESTAURANTE ===")
        for producto in self.productos:
            estado = "Disponible" if producto.disponible else "No disponible"
            print(f"{producto.nombre} - ${producto.obtener_precio():.2f} ({estado})")
