from modelos.platillo import Platillo
from modelos.bebida import Bebida
from servicios.restaurante import Restaurante

def main():
    mi_restaurante = Restaurante()

    print("=== REGISTRANDO PRODUCTOS ===")
    platillo1 = Platillo("Lomo Saltado", 15.50, 750, 20)
    platillo2 = Platillo("Ceviche", 12.00, 450, 15)

    bebida1 = Bebida("Jugo de Mango", 3.50, 500, False)
    bebida2 = Bebida("Cerveza Artesanal", 5.00, 330, True)

    mi_restaurante.agregar_producto(platillo1)
    mi_restaurante.agregar_producto(platillo2)
    mi_restaurante.agregar_producto(bebida1)
    mi_restaurante.agregar_producto(bebida2)

    print("\n--- Pruebas de Encapsulación ---")
    print(f"Precio original del Ceviche: ${platillo2.obtener_precio():.2f}")
    platillo2.cambiar_precio(-5.00)  # debería dar error
    platillo2.cambiar_precio(14.00)  # cambio válido
    print(f"Nuevo precio verificado del Ceviche: ${platillo2.obtener_precio():.2f}")

    mi_restaurante.mostrar_menu()

if __name__ == "__main__":
    main()
